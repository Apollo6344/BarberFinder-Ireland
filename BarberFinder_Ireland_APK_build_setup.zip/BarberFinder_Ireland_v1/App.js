import React, { useMemo, useState } from 'react';
import {
  SafeAreaView, View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, StatusBar, Alert
} from 'react-native';

const translations = {
  'en-GB': {
    language: 'English (UK)', otherLanguage: 'Português (Brasil)',
    tagline: 'Find your next great cut.', search: 'Search by barbershop or town',
    nearby: 'Registered barbershops', all: 'All', favourites: 'Favourites',
    bookings: 'Bookings', profile: 'Profile', book: 'Book', favourite: 'Favourite',
    favourited: 'Saved', from: 'From', services: 'Services', choose: 'Choose a barber',
    chooseDay: 'Choose a day', chooseTime: 'Choose a time', confirm: 'Confirm booking',
    noFavourites: 'Your favourite barbershops will appear here.',
    noBookings: 'Your bookings will appear here.', home: 'Explore',
    rating: 'rating', distance: 'away', booked: 'Booking saved in this demo!',
    selectBarber: 'Select a barber', selectDay: 'Select a day', selectTime: 'Select a time',
    searchResults: 'Search results', profileTitle: 'Your account',
    profileText: 'Customer account and sign-in will be added in a future version.',
    owner: 'Barbershop owner?', ownerText: 'Business dashboard is planned for the next build.',
    demo: 'DEMO VERSION', logo: 'LOGO', noResults: 'No registered barbershops match your search.',
    location: 'Roscrea, Ireland', view: 'View details', cancel: 'Cancel',
    selected: 'Selected', languageTitle: 'Language'
  },
  'pt-BR': {
    language: 'Português (Brasil)', otherLanguage: 'English (UK)',
    tagline: 'Encontre seu próximo corte.', search: 'Buscar barbearia ou cidade',
    nearby: 'Barbearias cadastradas', all: 'Todas', favourites: 'Favoritos',
    bookings: 'Agendamentos', profile: 'Perfil', book: 'Agendar', favourite: 'Favoritar',
    favourited: 'Salvo', from: 'A partir de', services: 'Serviços', choose: 'Escolha um barbeiro',
    chooseDay: 'Escolha um dia', chooseTime: 'Escolha um horário', confirm: 'Confirmar agendamento',
    noFavourites: 'Suas barbearias favoritas aparecerão aqui.',
    noBookings: 'Seus agendamentos aparecerão aqui.', home: 'Explorar',
    rating: 'avaliação', distance: 'de distância', booked: 'Agendamento salvo nesta demonstração!',
    selectBarber: 'Selecione um barbeiro', selectDay: 'Selecione um dia', selectTime: 'Selecione um horário',
    searchResults: 'Resultados da busca', profileTitle: 'Sua conta',
    profileText: 'A conta do cliente e o acesso serão adicionados em uma versão futura.',
    owner: 'É dono de barbearia?', ownerText: 'O painel da barbearia será desenvolvido na próxima versão.',
    demo: 'VERSÃO DEMONSTRATIVA', logo: 'LOGO', noResults: 'Nenhuma barbearia cadastrada corresponde à busca.',
    location: 'Roscrea, Irlanda', view: 'Ver detalhes', cancel: 'Cancelar',
    selected: 'Selecionado', languageTitle: 'Idioma'
  }
};

const BARBERSHOPS = [
  { id: '1', name: "King's Barber", town: 'Roscrea', rating: '4.8', distance: '0.7 km', price: 20, services: ['Haircut', 'Beard trim'], barbers: ['James', 'Ryan'], accent: 'K' },
  { id: '2', name: 'The Gentlemen’s Cut', town: 'Roscrea', rating: '4.9', distance: '1.2 km', price: 22, services: ['Haircut', 'Haircut + beard'], barbers: ['Daniel', 'Jack'], accent: 'G' },
  { id: '3', name: 'Classic Barbers', town: 'Nenagh', rating: '4.7', distance: '21 km', price: 18, services: ['Haircut', 'Beard trim'], barbers: ['Sean', 'Conor'], accent: 'C' },
];

export default function App() {
  const [lang, setLang] = useState('en-GB');
  const [tab, setTab] = useState('home');
  const [query, setQuery] = useState('');
  const [favs, setFavs] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [selectedShop, setSelectedShop] = useState(null);
  const [selectedBarber, setSelectedBarber] = useState('');
  const [selectedDay, setSelectedDay] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const t = translations[lang];

  const filtered = useMemo(() => BARBERSHOPS.filter(s =>
    (s.name + ' ' + s.town).toLowerCase().includes(query.toLowerCase())
  ), [query]);

  const toggleFav = (id) => setFavs(old => old.includes(id) ? old.filter(x => x !== id) : [...old, id]);
  const openBooking = (shop) => {
    setSelectedShop(shop); setSelectedBarber(''); setSelectedDay(''); setSelectedTime('');
  };
  const confirmBooking = () => {
    if (!selectedBarber || !selectedDay || !selectedTime) {
      Alert.alert(t.demo, `${t.selectBarber}, ${t.selectDay}, ${t.selectTime}.`);
      return;
    }
    setBookings(old => [...old, { id: Date.now().toString(), shop: selectedShop.name, barber: selectedBarber, day: selectedDay, time: selectedTime }]);
    setSelectedShop(null);
    setTab('bookings');
    Alert.alert(t.demo, t.booked);
  };

  const shopList = tab === 'favourites'
    ? BARBERSHOPS.filter(s => favs.includes(s.id))
    : filtered;

  const Button = ({ label, onPress, active = false, small = false }) => (
    <TouchableOpacity onPress={onPress} style={[styles.button, active && styles.buttonActive, small && styles.buttonSmall]}>
      <Text style={[styles.buttonText, active && styles.buttonTextActive, small && styles.buttonTextSmall]}>{label}</Text>
    </TouchableOpacity>
  );

  const renderShop = (shop) => (
    <View key={shop.id} style={styles.shopCard}>
      <View style={styles.shopTop}>
        <View style={styles.shopIcon}><Text style={styles.shopIconText}>{shop.accent}</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.shopName}>{shop.name}</Text>
          <Text style={styles.muted}>{shop.town} · {shop.distance}</Text>
          <Text style={styles.rating}>★ {shop.rating} <Text style={styles.muted}>{t.rating}</Text></Text>
        </View>
        <TouchableOpacity onPress={() => toggleFav(shop.id)} style={styles.heart}>
          <Text style={styles.heartText}>{favs.includes(shop.id) ? '♥' : '♡'}</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.cardBottom}>
        <Text style={styles.price}>{t.from} €{shop.price}</Text>
        <Button label={t.book} onPress={() => openBooking(shop)} active small />
      </View>
      <Text style={styles.serviceLine}>{shop.services.join('  ·  ')}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#101820" />
      <View style={styles.header}>
        <View style={styles.brandRow}>
          <View style={styles.logoBox}><Text style={styles.logoText}>{t.logo}</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.brand}>BarberFinder</Text>
            <Text style={styles.brandSub}>IRELAND</Text>
          </View>
          <TouchableOpacity style={styles.langButton} onPress={() => setLang(lang === 'en-GB' ? 'pt-BR' : 'en-GB')}>
            <Text style={styles.langButtonText}>{lang === 'en-GB' ? '🇬🇧 EN ▾' : '🇧🇷 PT ▾'}</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.tagline}>{t.tagline}</Text>
        <Text style={styles.demoBadge}>{t.demo}</Text>
      </View>

      {selectedShop ? (
        <ScrollView contentContainerStyle={styles.content}>
          <TouchableOpacity onPress={() => setSelectedShop(null)}><Text style={styles.back}>‹  {t.cancel}</Text></TouchableOpacity>
          <Text style={styles.sectionTitle}>{selectedShop.name}</Text>
          <Text style={styles.muted}>{selectedShop.town} · ★ {selectedShop.rating}</Text>
          <Text style={styles.subTitle}>{t.services}</Text>
          {selectedShop.services.map(s => <Text key={s} style={styles.listItem}>• {s}</Text>)}
          <Text style={styles.subTitle}>{t.choose}</Text>
          <View style={styles.wrapRow}>{selectedShop.barbers.map(b => <Button key={b} label={b} onPress={() => setSelectedBarber(b)} active={selectedBarber === b} small />)}</View>
          <Text style={styles.subTitle}>{t.chooseDay}</Text>
          <View style={styles.wrapRow}>{['Today', 'Tomorrow', 'Saturday'].map(d => <Button key={d} label={d} onPress={() => setSelectedDay(d)} active={selectedDay === d} small />)}</View>
          <Text style={styles.subTitle}>{t.chooseTime}</Text>
          <View style={styles.wrapRow}>{['10:00', '11:30', '14:00', '16:30'].map(tm => <Button key={tm} label={tm} onPress={() => setSelectedTime(tm)} active={selectedTime === tm} small />)}</View>
          <TouchableOpacity style={styles.primaryWide} onPress={confirmBooking}><Text style={styles.primaryWideText}>{t.confirm}</Text></TouchableOpacity>
          <Text style={styles.note}>Demo only: these sample times are not connected to a real booking calendar.</Text>
        </ScrollView>
      ) : (
        <>
          {tab === 'home' && (
            <ScrollView contentContainerStyle={styles.content}>
              <TextInput value={query} onChangeText={setQuery} placeholder={t.search} placeholderTextColor="#89939d" style={styles.search} />
              <View style={styles.locationPill}><Text style={styles.locationText}>📍 {t.location}</Text></View>
              <Text style={styles.sectionTitle}>{query ? t.searchResults : t.nearby}</Text>
              {filtered.length ? filtered.map(renderShop) : <Text style={styles.empty}>{t.noResults}</Text>}
            </ScrollView>
          )}
          {tab === 'favourites' && (
            <ScrollView contentContainerStyle={styles.content}>
              <Text style={styles.sectionTitle}>{t.favourites}</Text>
              {shopList.length ? shopList.map(renderShop) : <Text style={styles.empty}>{t.noFavourites}</Text>}
            </ScrollView>
          )}
          {tab === 'bookings' && (
            <ScrollView contentContainerStyle={styles.content}>
              <Text style={styles.sectionTitle}>{t.bookings}</Text>
              {bookings.length ? bookings.map(b => (
                <View key={b.id} style={styles.shopCard}>
                  <Text style={styles.shopName}>{b.shop}</Text>
                  <Text style={styles.muted}>{b.barber} · {b.day} · {b.time}</Text>
                  <Text style={styles.rating}>● {t.selected}</Text>
                </View>
              )) : <Text style={styles.empty}>{t.noBookings}</Text>}
            </ScrollView>
          )}
          {tab === 'profile' && (
            <ScrollView contentContainerStyle={styles.content}>
              <Text style={styles.sectionTitle}>{t.profileTitle}</Text>
              <View style={styles.shopCard}><Text style={styles.shopName}>{t.profile}</Text><Text style={styles.muted}>{t.profileText}</Text></View>
              <View style={styles.shopCard}><Text style={styles.shopName}>{t.owner}</Text><Text style={styles.muted}>{t.ownerText}</Text></View>
              <Text style={styles.note}>BarberFinder Ireland · Prototype v1</Text>
            </ScrollView>
          )}
          <View style={styles.tabBar}>
            {[
              ['home', '⌂', t.home],
              ['favourites', '♡', t.favourites],
              ['bookings', '▣', t.bookings],
              ['profile', '●', t.profile]
            ].map(([key, icon, label]) => (
              <TouchableOpacity key={key} style={styles.tabItem} onPress={() => setTab(key)}>
                <Text style={[styles.tabIcon, tab === key && styles.tabActive]}>{icon}</Text>
                <Text style={[styles.tabLabel, tab === key && styles.tabActive]}>{label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f3f5f7' },
  header: { backgroundColor: '#101820', paddingHorizontal: 18, paddingTop: 14, paddingBottom: 18 },
  brandRow: { flexDirection: 'row', alignItems: 'center' },
  logoBox: { width: 43, height: 43, borderRadius: 10, borderWidth: 1, borderColor: '#c7a76c', alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  logoText: { color: '#c7a76c', fontSize: 10, fontWeight: '800' },
  brand: { color: '#fff', fontSize: 21, fontWeight: '800', letterSpacing: 0.2 },
  brandSub: { color: '#c7a76c', fontSize: 10, fontWeight: '800', letterSpacing: 3, marginTop: 1 },
  langButton: { borderWidth: 1, borderColor: '#56616b', borderRadius: 9, paddingVertical: 9, paddingHorizontal: 10 },
  langButtonText: { color: '#fff', fontWeight: '700', fontSize: 12 },
  tagline: { color: '#e3e8ec', marginTop: 15, fontSize: 17, fontWeight: '600' },
  demoBadge: { color: '#c7a76c', fontSize: 9, fontWeight: '800', letterSpacing: 1.8, marginTop: 7 },
  content: { padding: 16, paddingBottom: 28 },
  search: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#dfe4e8', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, fontSize: 14, color: '#101820' },
  locationPill: { alignSelf: 'flex-start', backgroundColor: '#e7ecef', paddingVertical: 7, paddingHorizontal: 10, borderRadius: 20, marginTop: 11 },
  locationText: { color: '#34434f', fontSize: 12, fontWeight: '600' },
  sectionTitle: { color: '#101820', fontSize: 20, fontWeight: '800', marginTop: 22, marginBottom: 13 },
  shopCard: { backgroundColor: '#fff', borderRadius: 15, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#e5e9ed' },
  shopTop: { flexDirection: 'row', alignItems: 'center' },
  shopIcon: { width: 48, height: 48, borderRadius: 12, backgroundColor: '#e9dfcc', alignItems: 'center', justifyContent: 'center', marginRight: 11 },
  shopIconText: { fontSize: 22, color: '#725b32', fontWeight: '900' },
  shopName: { fontSize: 16, color: '#101820', fontWeight: '800', marginBottom: 3 },
  muted: { color: '#6f7a84', fontSize: 12, lineHeight: 18 },
  rating: { color: '#b0832f', fontSize: 12, fontWeight: '800', marginTop: 3 },
  heart: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#f5f6f7', alignItems: 'center', justifyContent: 'center' },
  heartText: { color: '#bd5260', fontSize: 23 },
  cardBottom: { borderTopWidth: 1, borderTopColor: '#edf0f2', marginTop: 13, paddingTop: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  price: { color: '#101820', fontSize: 14, fontWeight: '800' },
  serviceLine: { color: '#6f7a84', fontSize: 11, marginTop: 8 },
  button: { borderWidth: 1, borderColor: '#c7a76c', borderRadius: 10, paddingVertical: 10, paddingHorizontal: 14, marginRight: 7, marginBottom: 7 },
  buttonActive: { backgroundColor: '#101820', borderColor: '#101820' },
  buttonText: { color: '#101820', fontWeight: '700', fontSize: 13 },
  buttonTextActive: { color: '#fff' },
  buttonSmall: { paddingVertical: 8, paddingHorizontal: 12 },
  buttonTextSmall: { fontSize: 12 },
  tabBar: { flexDirection: 'row', backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#e0e5e8', paddingTop: 8, paddingBottom: 7 },
  tabItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  tabIcon: { fontSize: 20, color: '#87919a', fontWeight: '700' },
  tabLabel: { fontSize: 10, color: '#87919a', marginTop: 3, fontWeight: '600' },
  tabActive: { color: '#a27c3c' },
  empty: { backgroundColor: '#fff', padding: 18, borderRadius: 12, color: '#6f7a84', fontSize: 14, lineHeight: 21 },
  back: { color: '#735c33', fontSize: 15, fontWeight: '700', marginBottom: 8 },
  subTitle: { color: '#101820', fontSize: 15, fontWeight: '800', marginTop: 22, marginBottom: 10 },
  wrapRow: { flexDirection: 'row', flexWrap: 'wrap' },
  listItem: { color: '#34434f', fontSize: 14, marginBottom: 6 },
  primaryWide: { backgroundColor: '#101820', padding: 15, borderRadius: 12, alignItems: 'center', marginTop: 24 },
  primaryWideText: { color: '#fff', fontSize: 14, fontWeight: '800' },
  note: { color: '#89939d', fontSize: 11, lineHeight: 17, marginTop: 14 }
});
