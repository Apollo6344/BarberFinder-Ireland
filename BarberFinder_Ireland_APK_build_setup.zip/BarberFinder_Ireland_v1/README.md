# BarberFinder Ireland — protótipo móvel

Projeto React Native com Expo, preparado para gerar um APK Android por meio do serviço de compilação na nuvem Expo EAS Build.

## O que está incluído
- Interface em inglês (UK) e português (Brasil), com seletor de idioma.
- Busca demonstrativa de barbearias por nome/cidade.
- Favoritos, detalhes, serviços/preços de exemplo e fluxo demonstrativo de agendamento.
- Perfil visual inicial e espaço reservado para logótipo.
- `eas.json` configurado para gerar um APK de teste Android.

## Importante
Este projeto ainda é um protótipo visual. As barbearias e horários são exemplos, e os agendamentos ficam apenas na memória do app. Ainda não há base de dados, autenticação, GPS real, painel do proprietário/admin, cobrança de assinaturas ou notificações. Não deve ser publicado como produto final antes de implementar e testar esses recursos.

## Gerar o APK Android
É necessário iniciar uma compilação em nuvem usando uma conta Expo. A compilação não foi executada por este pacote.

Num terminal com Node.js instalado:

1. Extraia a pasta do projeto.
2. Execute `npm install`.
3. Execute `npx eas-cli login` e entre na sua conta Expo (ou crie uma em https://expo.dev).
4. Execute `npx eas-cli build:configure` se o EAS pedir para associar o projeto à conta.
5. Execute `npx eas-cli build --platform android --profile preview`.
6. Quando a compilação terminar, abra o link fornecido pelo EAS no Android e instale o APK.

O arquivo `eas.json` usa `buildType: apk` no perfil `preview`, para produzir um APK instalável para testes, em vez de um Android App Bundle da Play Store.

## Dependências
Expo SDK 52, React 18 e React Native 0.76.5.
